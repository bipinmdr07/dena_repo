def string_compressor(string)
  # Write your code here!
end