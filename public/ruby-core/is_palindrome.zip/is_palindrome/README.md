## Factorial

## Initial Setup

To run the test suite, first run bundle install

```
bundle install
```

## To run the test

Run the test file by running the command:

```
bundle exec rspec
```