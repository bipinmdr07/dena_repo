def is_palindrome?(string)
  # Write your code here!
end